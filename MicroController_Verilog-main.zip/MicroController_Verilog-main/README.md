# MicroController_Verilog
1 cycle MC in Verilog
